package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText usernm,passwrd;
    Button loginbt;
    String name="Anannya";
    String pass="456123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernm = findViewById(R.id.Username);
        passwrd = findViewById(R.id.Password);
        loginbt = findViewById(R.id.Login);

        loginbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inpuser = usernm.getText().toString();
                String inppass = passwrd.getText().toString();

                if (inpuser.isEmpty() || inppass.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Fields are Empty", Toast.LENGTH_SHORT).show();
                }

                else
                {

                    if (inpuser.equals(name) && inppass.equals(pass))
                    {
                        Toast.makeText(MainActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                    }

                    if (!inpuser.equals(name))
                    {
                        Toast.makeText(MainActivity.this, "Incorrect Username", Toast.LENGTH_SHORT).show();
                    }

                    if (!inppass.equals(pass))
                    {
                        Toast.makeText(MainActivity.this, "Incorrect Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}