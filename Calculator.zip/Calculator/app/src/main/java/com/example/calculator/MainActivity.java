package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText val1,val2;
    Button bt1,bt2,bt3,bt4;
    float c=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        val1 = findViewById(R.id.Value1);
        val2 = findViewById(R.id.Value2);
        bt1 = findViewById(R.id.ButtonAdd);
        bt2 = findViewById(R.id.ButtonSub);
        bt3 = findViewById(R.id.ButtonMult);
        bt4 = findViewById(R.id.ButtonDiv);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float a =  Float.parseFloat(val1.getText().toString());
                float b =  Float.parseFloat(val2.getText().toString());
                c=a+b;
                Toast.makeText(MainActivity.this, "Sum is : "+c, Toast.LENGTH_SHORT).show();

            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float a = Float.parseFloat(val1.getText().toString());
                float b = Float.parseFloat(val2.getText().toString());
                c = a-b;
                Toast.makeText(MainActivity.this, "Difference is : "+c, Toast.LENGTH_SHORT).show();
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float a = Float.parseFloat(val1.getText().toString());
                float b = Float.parseFloat(val2.getText().toString());
                c = a*b;
                Toast.makeText(MainActivity.this, "Product is : "+c, Toast.LENGTH_SHORT).show();
            }
        });

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float a = Float.parseFloat(val1.getText().toString());
                float b = Float.parseFloat(val2.getText().toString());
                c = a/b;
                Toast.makeText(MainActivity.this, "Division is : "+c, Toast.LENGTH_SHORT).show();
            }
        });

    }
}
